﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_Calculator
	Inherits System.Windows.Forms.Form

	'Form reemplaza a Dispose para limpiar la lista de componentes.
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Requerido por el Diseñador de Windows Forms
	Private components As System.ComponentModel.IContainer

	'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
	'Se puede modificar usando el Diseñador de Windows Forms.  
	'No lo modifique con el editor de código.
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
        Me.btn_7 = New System.Windows.Forms.Button()
        Me.btn_8 = New System.Windows.Forms.Button()
        Me.btn_9 = New System.Windows.Forms.Button()
        Me.btn_4 = New System.Windows.Forms.Button()
        Me.btn_5 = New System.Windows.Forms.Button()
        Me.btn_6 = New System.Windows.Forms.Button()
        Me.btn_3 = New System.Windows.Forms.Button()
        Me.btn_2 = New System.Windows.Forms.Button()
        Me.btn_1 = New System.Windows.Forms.Button()
        Me.btn_Sub = New System.Windows.Forms.Button()
        Me.btn_Mult = New System.Windows.Forms.Button()
        Me.btn_Div = New System.Windows.Forms.Button()
        Me.btn_0 = New System.Windows.Forms.Button()
        Me.btn_Coma = New System.Windows.Forms.Button()
        Me.btn_Add = New System.Windows.Forms.Button()
        Me.btn_Equal = New System.Windows.Forms.Button()
        Me.btn_Delete = New System.Windows.Forms.Button()
        Me.btn_Clean = New System.Windows.Forms.Button()
        Me.tb_Display = New System.Windows.Forms.TextBox()
        Me.tb_Debug = New System.Windows.Forms.TextBox()
        Me.btn_DD = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btn_7
        '
        Me.btn_7.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_7.Location = New System.Drawing.Point(12, 185)
        Me.btn_7.Name = "btn_7"
        Me.btn_7.Size = New System.Drawing.Size(50, 50)
        Me.btn_7.TabIndex = 0
        Me.btn_7.Text = "7"
        Me.btn_7.UseVisualStyleBackColor = True
        '
        'btn_8
        '
        Me.btn_8.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_8.Location = New System.Drawing.Point(68, 185)
        Me.btn_8.Name = "btn_8"
        Me.btn_8.Size = New System.Drawing.Size(50, 50)
        Me.btn_8.TabIndex = 1
        Me.btn_8.Text = "8"
        Me.btn_8.UseVisualStyleBackColor = True
        '
        'btn_9
        '
        Me.btn_9.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_9.Location = New System.Drawing.Point(124, 185)
        Me.btn_9.Name = "btn_9"
        Me.btn_9.Size = New System.Drawing.Size(50, 50)
        Me.btn_9.TabIndex = 2
        Me.btn_9.Text = "9"
        Me.btn_9.UseVisualStyleBackColor = True
        '
        'btn_4
        '
        Me.btn_4.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_4.Location = New System.Drawing.Point(12, 241)
        Me.btn_4.Name = "btn_4"
        Me.btn_4.Size = New System.Drawing.Size(50, 50)
        Me.btn_4.TabIndex = 3
        Me.btn_4.Text = "4"
        Me.btn_4.UseVisualStyleBackColor = True
        '
        'btn_5
        '
        Me.btn_5.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_5.Location = New System.Drawing.Point(68, 241)
        Me.btn_5.Name = "btn_5"
        Me.btn_5.Size = New System.Drawing.Size(50, 50)
        Me.btn_5.TabIndex = 4
        Me.btn_5.Text = "5"
        Me.btn_5.UseVisualStyleBackColor = True
        '
        'btn_6
        '
        Me.btn_6.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_6.Location = New System.Drawing.Point(124, 241)
        Me.btn_6.Name = "btn_6"
        Me.btn_6.Size = New System.Drawing.Size(50, 50)
        Me.btn_6.TabIndex = 5
        Me.btn_6.Text = "6"
        Me.btn_6.UseVisualStyleBackColor = True
        '
        'btn_3
        '
        Me.btn_3.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_3.Location = New System.Drawing.Point(124, 297)
        Me.btn_3.Name = "btn_3"
        Me.btn_3.Size = New System.Drawing.Size(50, 50)
        Me.btn_3.TabIndex = 8
        Me.btn_3.Text = "3"
        Me.btn_3.UseVisualStyleBackColor = True
        '
        'btn_2
        '
        Me.btn_2.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_2.Location = New System.Drawing.Point(68, 297)
        Me.btn_2.Name = "btn_2"
        Me.btn_2.Size = New System.Drawing.Size(50, 50)
        Me.btn_2.TabIndex = 7
        Me.btn_2.Text = "2"
        Me.btn_2.UseVisualStyleBackColor = True
        '
        'btn_1
        '
        Me.btn_1.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_1.Location = New System.Drawing.Point(12, 297)
        Me.btn_1.Name = "btn_1"
        Me.btn_1.Size = New System.Drawing.Size(50, 50)
        Me.btn_1.TabIndex = 6
        Me.btn_1.Text = "1"
        Me.btn_1.UseVisualStyleBackColor = True
        '
        'btn_Sub
        '
        Me.btn_Sub.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Sub.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_Sub.Location = New System.Drawing.Point(190, 241)
        Me.btn_Sub.Name = "btn_Sub"
        Me.btn_Sub.Size = New System.Drawing.Size(50, 50)
        Me.btn_Sub.TabIndex = 11
        Me.btn_Sub.Text = "─"
        Me.btn_Sub.UseVisualStyleBackColor = True
        '
        'btn_Mult
        '
        Me.btn_Mult.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Mult.Location = New System.Drawing.Point(190, 185)
        Me.btn_Mult.Name = "btn_Mult"
        Me.btn_Mult.Size = New System.Drawing.Size(50, 50)
        Me.btn_Mult.TabIndex = 10
        Me.btn_Mult.Text = "X"
        Me.btn_Mult.UseVisualStyleBackColor = True
        '
        'btn_Div
        '
        Me.btn_Div.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Div.Location = New System.Drawing.Point(190, 129)
        Me.btn_Div.Name = "btn_Div"
        Me.btn_Div.Size = New System.Drawing.Size(50, 50)
        Me.btn_Div.TabIndex = 9
        Me.btn_Div.Text = "÷"
        Me.btn_Div.UseVisualStyleBackColor = True
        '
        'btn_0
        '
        Me.btn_0.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_0.Location = New System.Drawing.Point(12, 353)
        Me.btn_0.Name = "btn_0"
        Me.btn_0.Size = New System.Drawing.Size(106, 50)
        Me.btn_0.TabIndex = 12
        Me.btn_0.Text = "Ø"
        Me.btn_0.UseVisualStyleBackColor = True
        '
        'btn_Coma
        '
        Me.btn_Coma.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Coma.Location = New System.Drawing.Point(124, 353)
        Me.btn_Coma.Name = "btn_Coma"
        Me.btn_Coma.Size = New System.Drawing.Size(50, 50)
        Me.btn_Coma.TabIndex = 13
        Me.btn_Coma.Text = ","
        Me.btn_Coma.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_Coma.UseVisualStyleBackColor = True
        '
        'btn_Add
        '
        Me.btn_Add.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Add.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_Add.Location = New System.Drawing.Point(190, 297)
        Me.btn_Add.Name = "btn_Add"
        Me.btn_Add.Size = New System.Drawing.Size(50, 50)
        Me.btn_Add.TabIndex = 14
        Me.btn_Add.Text = "+"
        Me.btn_Add.UseVisualStyleBackColor = True
        '
        'btn_Equal
        '
        Me.btn_Equal.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Equal.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_Equal.Location = New System.Drawing.Point(190, 353)
        Me.btn_Equal.Name = "btn_Equal"
        Me.btn_Equal.Size = New System.Drawing.Size(50, 50)
        Me.btn_Equal.TabIndex = 15
        Me.btn_Equal.Text = "="
        Me.btn_Equal.UseVisualStyleBackColor = True
        '
        'btn_Delete
        '
        Me.btn_Delete.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Delete.Location = New System.Drawing.Point(68, 129)
        Me.btn_Delete.Name = "btn_Delete"
        Me.btn_Delete.Size = New System.Drawing.Size(106, 50)
        Me.btn_Delete.TabIndex = 16
        Me.btn_Delete.Text = "«"
        Me.btn_Delete.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_Delete.UseVisualStyleBackColor = True
        '
        'btn_Clean
        '
        Me.btn_Clean.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Clean.Location = New System.Drawing.Point(12, 129)
        Me.btn_Clean.Name = "btn_Clean"
        Me.btn_Clean.Size = New System.Drawing.Size(50, 50)
        Me.btn_Clean.TabIndex = 17
        Me.btn_Clean.Text = "CE"
        Me.btn_Clean.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_Clean.UseVisualStyleBackColor = True
        '
        'tb_Display
        '
        Me.tb_Display.Enabled = False
        Me.tb_Display.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_Display.Location = New System.Drawing.Point(12, 15)
        Me.tb_Display.Multiline = True
        Me.tb_Display.Name = "tb_Display"
        Me.tb_Display.ReadOnly = True
        Me.tb_Display.Size = New System.Drawing.Size(228, 99)
        Me.tb_Display.TabIndex = 19
        Me.tb_Display.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tb_Debug
        '
        Me.tb_Debug.Location = New System.Drawing.Point(12, 442)
        Me.tb_Debug.Multiline = True
        Me.tb_Debug.Name = "tb_Debug"
        Me.tb_Debug.ReadOnly = True
        Me.tb_Debug.Size = New System.Drawing.Size(228, 180)
        Me.tb_Debug.TabIndex = 20
        '
        'btn_DD
        '
        Me.btn_DD.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!)
        Me.btn_DD.Location = New System.Drawing.Point(11, 413)
        Me.btn_DD.Margin = New System.Windows.Forms.Padding(0)
        Me.btn_DD.Name = "btn_DD"
        Me.btn_DD.Size = New System.Drawing.Size(30, 30)
        Me.btn_DD.TabIndex = 21
        Me.btn_DD.Text = "^"
        Me.btn_DD.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Label1.Location = New System.Drawing.Point(44, 415)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(81, 25)
        Me.Label1.TabIndex = 22
        Me.Label1.Text = "Historial"
        '
        'frm_Calculator
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.ClientSize = New System.Drawing.Size(254, 441)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btn_DD)
        Me.Controls.Add(Me.tb_Debug)
        Me.Controls.Add(Me.tb_Display)
        Me.Controls.Add(Me.btn_Clean)
        Me.Controls.Add(Me.btn_Delete)
        Me.Controls.Add(Me.btn_Equal)
        Me.Controls.Add(Me.btn_Add)
        Me.Controls.Add(Me.btn_Coma)
        Me.Controls.Add(Me.btn_0)
        Me.Controls.Add(Me.btn_Sub)
        Me.Controls.Add(Me.btn_Mult)
        Me.Controls.Add(Me.btn_Div)
        Me.Controls.Add(Me.btn_3)
        Me.Controls.Add(Me.btn_2)
        Me.Controls.Add(Me.btn_1)
        Me.Controls.Add(Me.btn_6)
        Me.Controls.Add(Me.btn_5)
        Me.Controls.Add(Me.btn_4)
        Me.Controls.Add(Me.btn_9)
        Me.Controls.Add(Me.btn_8)
        Me.Controls.Add(Me.btn_7)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Name = "frm_Calculator"
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btn_7 As Button
	Friend WithEvents btn_8 As Button
	Friend WithEvents btn_9 As Button
	Friend WithEvents btn_4 As Button
	Friend WithEvents btn_5 As Button
	Friend WithEvents btn_6 As Button
	Friend WithEvents btn_3 As Button
	Friend WithEvents btn_2 As Button
	Friend WithEvents btn_1 As Button
	Friend WithEvents btn_Sub As Button
	Friend WithEvents btn_Mult As Button
	Friend WithEvents btn_Div As Button
	Friend WithEvents btn_0 As Button
	Friend WithEvents btn_Coma As Button
	Friend WithEvents btn_Add As Button
	Friend WithEvents btn_Equal As Button
	Friend WithEvents btn_Delete As Button
	Friend WithEvents btn_Clean As Button
	Friend WithEvents btn_Mod As Button
	Friend WithEvents tb_Display As TextBox
	Friend WithEvents tb_Debug As TextBox
	Friend WithEvents btn_DD As Button
	Friend WithEvents Label1 As Label
End Class
