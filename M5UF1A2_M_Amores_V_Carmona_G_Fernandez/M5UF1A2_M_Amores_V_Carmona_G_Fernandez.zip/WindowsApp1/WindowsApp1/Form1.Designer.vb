﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnmasmenos = New System.Windows.Forms.Button()
        Me.btnigual = New System.Windows.Forms.Button()
        Me.btnpunto = New System.Windows.Forms.Button()
        Me.btnzero = New System.Windows.Forms.Button()
        Me.btndos = New System.Windows.Forms.Button()
        Me.btntres = New System.Windows.Forms.Button()
        Me.btnsuma = New System.Windows.Forms.Button()
        Me.btnuno = New System.Windows.Forms.Button()
        Me.btncinco = New System.Windows.Forms.Button()
        Me.btnseis = New System.Windows.Forms.Button()
        Me.btnresta = New System.Windows.Forms.Button()
        Me.btncuatro = New System.Windows.Forms.Button()
        Me.btnocho = New System.Windows.Forms.Button()
        Me.btnnueve = New System.Windows.Forms.Button()
        Me.btnmultiplicacion = New System.Windows.Forms.Button()
        Me.btnsiete = New System.Windows.Forms.Button()
        Me.btnclear = New System.Windows.Forms.Button()
        Me.btnbackspace = New System.Windows.Forms.Button()
        Me.btndivision = New System.Windows.Forms.Button()
        Me.btnraiz = New System.Windows.Forms.Button()
        Me.btncuadrado = New System.Windows.Forms.Button()
        Me.btnreciproco = New System.Windows.Forms.Button()
        Me.btnporcentaje = New System.Windows.Forms.Button()
        Me.btndiezx = New System.Windows.Forms.Button()
        Me.btnexp = New System.Windows.Forms.Button()
        Me.bntpi = New System.Windows.Forms.Button()
        Me.btnpotvariable = New System.Windows.Forms.Button()
        Me.btncos = New System.Windows.Forms.Button()
        Me.btntan = New System.Windows.Forms.Button()
        Me.btnlog = New System.Windows.Forms.Button()
        Me.btnsin = New System.Windows.Forms.Button()
        Me.btnmc = New System.Windows.Forms.Button()
        Me.btnmr = New System.Windows.Forms.Button()
        Me.bntms = New System.Windows.Forms.Button()
        Me.txtref = New System.Windows.Forms.TextBox()
        Me.txtpantalla = New System.Windows.Forms.TextBox()
        Me.lblMEM = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnmasmenos
        '
        Me.btnmasmenos.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnmasmenos.FlatAppearance.BorderSize = 0
        Me.btnmasmenos.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnmasmenos.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnmasmenos.ForeColor = System.Drawing.SystemColors.Control
        Me.btnmasmenos.Location = New System.Drawing.Point(10, 624)
        Me.btnmasmenos.Margin = New System.Windows.Forms.Padding(2)
        Me.btnmasmenos.Name = "btnmasmenos"
        Me.btnmasmenos.Size = New System.Drawing.Size(70, 50)
        Me.btnmasmenos.TabIndex = 4
        Me.btnmasmenos.Text = "±"
        Me.btnmasmenos.UseVisualStyleBackColor = False
        '
        'btnigual
        '
        Me.btnigual.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnigual.FlatAppearance.BorderSize = 0
        Me.btnigual.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnigual.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnigual.ForeColor = System.Drawing.SystemColors.Control
        Me.btnigual.Location = New System.Drawing.Point(235, 624)
        Me.btnigual.Margin = New System.Windows.Forms.Padding(2)
        Me.btnigual.Name = "btnigual"
        Me.btnigual.Size = New System.Drawing.Size(70, 50)
        Me.btnigual.TabIndex = 5
        Me.btnigual.Text = "="
        Me.btnigual.UseVisualStyleBackColor = False
        '
        'btnpunto
        '
        Me.btnpunto.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnpunto.FlatAppearance.BorderSize = 0
        Me.btnpunto.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnpunto.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnpunto.ForeColor = System.Drawing.SystemColors.Control
        Me.btnpunto.Location = New System.Drawing.Point(160, 624)
        Me.btnpunto.Margin = New System.Windows.Forms.Padding(2)
        Me.btnpunto.Name = "btnpunto"
        Me.btnpunto.Size = New System.Drawing.Size(70, 50)
        Me.btnpunto.TabIndex = 6
        Me.btnpunto.Text = ","
        Me.btnpunto.UseVisualStyleBackColor = False
        '
        'btnzero
        '
        Me.btnzero.BackColor = System.Drawing.Color.Black
        Me.btnzero.FlatAppearance.BorderSize = 0
        Me.btnzero.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnzero.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnzero.ForeColor = System.Drawing.SystemColors.Control
        Me.btnzero.Location = New System.Drawing.Point(85, 624)
        Me.btnzero.Margin = New System.Windows.Forms.Padding(2)
        Me.btnzero.Name = "btnzero"
        Me.btnzero.Size = New System.Drawing.Size(70, 50)
        Me.btnzero.TabIndex = 7
        Me.btnzero.Text = "0"
        Me.btnzero.UseVisualStyleBackColor = False
        '
        'btndos
        '
        Me.btndos.BackColor = System.Drawing.Color.Black
        Me.btndos.FlatAppearance.BorderSize = 0
        Me.btndos.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btndos.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btndos.ForeColor = System.Drawing.SystemColors.Control
        Me.btndos.Location = New System.Drawing.Point(85, 569)
        Me.btndos.Margin = New System.Windows.Forms.Padding(2)
        Me.btndos.Name = "btndos"
        Me.btndos.Size = New System.Drawing.Size(70, 50)
        Me.btndos.TabIndex = 11
        Me.btndos.Text = "2"
        Me.btndos.UseVisualStyleBackColor = False
        '
        'btntres
        '
        Me.btntres.BackColor = System.Drawing.Color.Black
        Me.btntres.FlatAppearance.BorderSize = 0
        Me.btntres.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btntres.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btntres.ForeColor = System.Drawing.SystemColors.Control
        Me.btntres.Location = New System.Drawing.Point(160, 569)
        Me.btntres.Margin = New System.Windows.Forms.Padding(2)
        Me.btntres.Name = "btntres"
        Me.btntres.Size = New System.Drawing.Size(70, 50)
        Me.btntres.TabIndex = 10
        Me.btntres.Text = "3"
        Me.btntres.UseVisualStyleBackColor = False
        '
        'btnsuma
        '
        Me.btnsuma.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnsuma.FlatAppearance.BorderSize = 0
        Me.btnsuma.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnsuma.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsuma.ForeColor = System.Drawing.SystemColors.Control
        Me.btnsuma.Location = New System.Drawing.Point(235, 569)
        Me.btnsuma.Margin = New System.Windows.Forms.Padding(2)
        Me.btnsuma.Name = "btnsuma"
        Me.btnsuma.Size = New System.Drawing.Size(70, 50)
        Me.btnsuma.TabIndex = 9
        Me.btnsuma.Text = "+"
        Me.btnsuma.UseVisualStyleBackColor = False
        '
        'btnuno
        '
        Me.btnuno.BackColor = System.Drawing.Color.Black
        Me.btnuno.FlatAppearance.BorderSize = 0
        Me.btnuno.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnuno.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnuno.ForeColor = System.Drawing.SystemColors.Control
        Me.btnuno.Location = New System.Drawing.Point(10, 569)
        Me.btnuno.Margin = New System.Windows.Forms.Padding(2)
        Me.btnuno.Name = "btnuno"
        Me.btnuno.Size = New System.Drawing.Size(70, 50)
        Me.btnuno.TabIndex = 8
        Me.btnuno.Text = "1"
        Me.btnuno.UseVisualStyleBackColor = False
        '
        'btncinco
        '
        Me.btncinco.BackColor = System.Drawing.Color.Black
        Me.btncinco.FlatAppearance.BorderSize = 0
        Me.btncinco.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btncinco.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncinco.ForeColor = System.Drawing.SystemColors.Control
        Me.btncinco.Location = New System.Drawing.Point(85, 514)
        Me.btncinco.Margin = New System.Windows.Forms.Padding(2)
        Me.btncinco.Name = "btncinco"
        Me.btncinco.Size = New System.Drawing.Size(70, 50)
        Me.btncinco.TabIndex = 15
        Me.btncinco.Text = "5"
        Me.btncinco.UseVisualStyleBackColor = False
        '
        'btnseis
        '
        Me.btnseis.BackColor = System.Drawing.Color.Black
        Me.btnseis.FlatAppearance.BorderSize = 0
        Me.btnseis.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnseis.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnseis.ForeColor = System.Drawing.SystemColors.Control
        Me.btnseis.Location = New System.Drawing.Point(160, 514)
        Me.btnseis.Margin = New System.Windows.Forms.Padding(2)
        Me.btnseis.Name = "btnseis"
        Me.btnseis.Size = New System.Drawing.Size(70, 50)
        Me.btnseis.TabIndex = 14
        Me.btnseis.Text = "6"
        Me.btnseis.UseVisualStyleBackColor = False
        '
        'btnresta
        '
        Me.btnresta.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnresta.FlatAppearance.BorderSize = 0
        Me.btnresta.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnresta.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnresta.ForeColor = System.Drawing.SystemColors.Control
        Me.btnresta.Location = New System.Drawing.Point(235, 514)
        Me.btnresta.Margin = New System.Windows.Forms.Padding(2)
        Me.btnresta.Name = "btnresta"
        Me.btnresta.Size = New System.Drawing.Size(70, 50)
        Me.btnresta.TabIndex = 13
        Me.btnresta.Text = "-"
        Me.btnresta.UseVisualStyleBackColor = False
        '
        'btncuatro
        '
        Me.btncuatro.BackColor = System.Drawing.Color.Black
        Me.btncuatro.FlatAppearance.BorderSize = 0
        Me.btncuatro.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btncuatro.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncuatro.ForeColor = System.Drawing.SystemColors.Control
        Me.btncuatro.Location = New System.Drawing.Point(10, 514)
        Me.btncuatro.Margin = New System.Windows.Forms.Padding(2)
        Me.btncuatro.Name = "btncuatro"
        Me.btncuatro.Size = New System.Drawing.Size(70, 50)
        Me.btncuatro.TabIndex = 12
        Me.btncuatro.Text = "4"
        Me.btncuatro.UseVisualStyleBackColor = False
        '
        'btnocho
        '
        Me.btnocho.BackColor = System.Drawing.Color.Black
        Me.btnocho.FlatAppearance.BorderSize = 0
        Me.btnocho.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnocho.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnocho.ForeColor = System.Drawing.SystemColors.Control
        Me.btnocho.Location = New System.Drawing.Point(85, 458)
        Me.btnocho.Margin = New System.Windows.Forms.Padding(2)
        Me.btnocho.Name = "btnocho"
        Me.btnocho.Size = New System.Drawing.Size(70, 50)
        Me.btnocho.TabIndex = 19
        Me.btnocho.Text = "8"
        Me.btnocho.UseVisualStyleBackColor = False
        '
        'btnnueve
        '
        Me.btnnueve.BackColor = System.Drawing.Color.Black
        Me.btnnueve.FlatAppearance.BorderSize = 0
        Me.btnnueve.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnnueve.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnnueve.ForeColor = System.Drawing.SystemColors.Control
        Me.btnnueve.Location = New System.Drawing.Point(160, 458)
        Me.btnnueve.Margin = New System.Windows.Forms.Padding(2)
        Me.btnnueve.Name = "btnnueve"
        Me.btnnueve.Size = New System.Drawing.Size(70, 50)
        Me.btnnueve.TabIndex = 18
        Me.btnnueve.Text = "9"
        Me.btnnueve.UseVisualStyleBackColor = False
        '
        'btnmultiplicacion
        '
        Me.btnmultiplicacion.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnmultiplicacion.FlatAppearance.BorderSize = 0
        Me.btnmultiplicacion.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnmultiplicacion.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnmultiplicacion.ForeColor = System.Drawing.SystemColors.Control
        Me.btnmultiplicacion.Location = New System.Drawing.Point(235, 458)
        Me.btnmultiplicacion.Margin = New System.Windows.Forms.Padding(2)
        Me.btnmultiplicacion.Name = "btnmultiplicacion"
        Me.btnmultiplicacion.Size = New System.Drawing.Size(70, 50)
        Me.btnmultiplicacion.TabIndex = 17
        Me.btnmultiplicacion.Text = "×"
        Me.btnmultiplicacion.UseVisualStyleBackColor = False
        '
        'btnsiete
        '
        Me.btnsiete.BackColor = System.Drawing.Color.Black
        Me.btnsiete.FlatAppearance.BorderSize = 0
        Me.btnsiete.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnsiete.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsiete.ForeColor = System.Drawing.SystemColors.Control
        Me.btnsiete.Location = New System.Drawing.Point(10, 458)
        Me.btnsiete.Margin = New System.Windows.Forms.Padding(2)
        Me.btnsiete.Name = "btnsiete"
        Me.btnsiete.Size = New System.Drawing.Size(70, 50)
        Me.btnsiete.TabIndex = 16
        Me.btnsiete.Text = "7"
        Me.btnsiete.UseVisualStyleBackColor = False
        '
        'btnclear
        '
        Me.btnclear.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnclear.FlatAppearance.BorderSize = 0
        Me.btnclear.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnclear.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnclear.ForeColor = System.Drawing.SystemColors.Control
        Me.btnclear.Location = New System.Drawing.Point(85, 403)
        Me.btnclear.Margin = New System.Windows.Forms.Padding(2)
        Me.btnclear.Name = "btnclear"
        Me.btnclear.Size = New System.Drawing.Size(70, 50)
        Me.btnclear.TabIndex = 23
        Me.btnclear.Text = "C"
        Me.btnclear.UseVisualStyleBackColor = False
        '
        'btnbackspace
        '
        Me.btnbackspace.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnbackspace.FlatAppearance.BorderSize = 0
        Me.btnbackspace.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnbackspace.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnbackspace.ForeColor = System.Drawing.SystemColors.Control
        Me.btnbackspace.Location = New System.Drawing.Point(160, 403)
        Me.btnbackspace.Margin = New System.Windows.Forms.Padding(2)
        Me.btnbackspace.Name = "btnbackspace"
        Me.btnbackspace.Size = New System.Drawing.Size(70, 50)
        Me.btnbackspace.TabIndex = 22
        Me.btnbackspace.Text = "⌫"
        Me.btnbackspace.UseVisualStyleBackColor = False
        '
        'btndivision
        '
        Me.btndivision.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btndivision.FlatAppearance.BorderSize = 0
        Me.btndivision.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btndivision.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btndivision.ForeColor = System.Drawing.SystemColors.Control
        Me.btndivision.Location = New System.Drawing.Point(235, 403)
        Me.btndivision.Margin = New System.Windows.Forms.Padding(2)
        Me.btndivision.Name = "btndivision"
        Me.btndivision.Size = New System.Drawing.Size(70, 50)
        Me.btndivision.TabIndex = 21
        Me.btndivision.Text = "÷"
        Me.btndivision.UseVisualStyleBackColor = False
        '
        'btnraiz
        '
        Me.btnraiz.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnraiz.FlatAppearance.BorderSize = 0
        Me.btnraiz.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnraiz.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnraiz.ForeColor = System.Drawing.SystemColors.Control
        Me.btnraiz.Location = New System.Drawing.Point(86, 326)
        Me.btnraiz.Margin = New System.Windows.Forms.Padding(2)
        Me.btnraiz.Name = "btnraiz"
        Me.btnraiz.Size = New System.Drawing.Size(70, 50)
        Me.btnraiz.TabIndex = 27
        Me.btnraiz.Text = "√ "
        Me.btnraiz.UseVisualStyleBackColor = False
        '
        'btncuadrado
        '
        Me.btncuadrado.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btncuadrado.FlatAppearance.BorderSize = 0
        Me.btncuadrado.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btncuadrado.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncuadrado.ForeColor = System.Drawing.SystemColors.Control
        Me.btncuadrado.Location = New System.Drawing.Point(160, 326)
        Me.btncuadrado.Margin = New System.Windows.Forms.Padding(2)
        Me.btncuadrado.Name = "btncuadrado"
        Me.btncuadrado.Size = New System.Drawing.Size(70, 50)
        Me.btncuadrado.TabIndex = 26
        Me.btncuadrado.Text = "x²"
        Me.btncuadrado.UseVisualStyleBackColor = False
        '
        'btnreciproco
        '
        Me.btnreciproco.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnreciproco.FlatAppearance.BorderSize = 0
        Me.btnreciproco.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnreciproco.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnreciproco.ForeColor = System.Drawing.SystemColors.Control
        Me.btnreciproco.Location = New System.Drawing.Point(236, 326)
        Me.btnreciproco.Margin = New System.Windows.Forms.Padding(2)
        Me.btnreciproco.Name = "btnreciproco"
        Me.btnreciproco.Size = New System.Drawing.Size(70, 50)
        Me.btnreciproco.TabIndex = 25
        Me.btnreciproco.Text = "¹⁄ₓ"
        Me.btnreciproco.UseVisualStyleBackColor = False
        '
        'btnporcentaje
        '
        Me.btnporcentaje.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnporcentaje.FlatAppearance.BorderSize = 0
        Me.btnporcentaje.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnporcentaje.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnporcentaje.ForeColor = System.Drawing.SystemColors.Control
        Me.btnporcentaje.Location = New System.Drawing.Point(10, 326)
        Me.btnporcentaje.Margin = New System.Windows.Forms.Padding(2)
        Me.btnporcentaje.Name = "btnporcentaje"
        Me.btnporcentaje.Size = New System.Drawing.Size(70, 50)
        Me.btnporcentaje.TabIndex = 24
        Me.btnporcentaje.Text = "%"
        Me.btnporcentaje.UseVisualStyleBackColor = False
        '
        'btndiezx
        '
        Me.btndiezx.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btndiezx.FlatAppearance.BorderSize = 0
        Me.btndiezx.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btndiezx.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btndiezx.ForeColor = System.Drawing.SystemColors.Control
        Me.btndiezx.Location = New System.Drawing.Point(86, 215)
        Me.btndiezx.Margin = New System.Windows.Forms.Padding(2)
        Me.btndiezx.Name = "btndiezx"
        Me.btndiezx.Size = New System.Drawing.Size(70, 50)
        Me.btndiezx.TabIndex = 31
        Me.btndiezx.Text = "10ˣ"
        Me.btndiezx.UseVisualStyleBackColor = False
        '
        'btnexp
        '
        Me.btnexp.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnexp.FlatAppearance.BorderSize = 0
        Me.btnexp.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnexp.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnexp.ForeColor = System.Drawing.SystemColors.Control
        Me.btnexp.Location = New System.Drawing.Point(160, 215)
        Me.btnexp.Margin = New System.Windows.Forms.Padding(2)
        Me.btnexp.Name = "btnexp"
        Me.btnexp.Size = New System.Drawing.Size(70, 50)
        Me.btnexp.TabIndex = 30
        Me.btnexp.Text = "Exp"
        Me.btnexp.UseVisualStyleBackColor = False
        '
        'bntpi
        '
        Me.bntpi.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.bntpi.FlatAppearance.BorderSize = 0
        Me.bntpi.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bntpi.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bntpi.ForeColor = System.Drawing.SystemColors.Control
        Me.bntpi.Location = New System.Drawing.Point(236, 215)
        Me.bntpi.Margin = New System.Windows.Forms.Padding(2)
        Me.bntpi.Name = "bntpi"
        Me.bntpi.Size = New System.Drawing.Size(70, 50)
        Me.bntpi.TabIndex = 29
        Me.bntpi.Text = "𝛑"
        Me.bntpi.UseVisualStyleBackColor = False
        '
        'btnpotvariable
        '
        Me.btnpotvariable.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnpotvariable.FlatAppearance.BorderSize = 0
        Me.btnpotvariable.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnpotvariable.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnpotvariable.ForeColor = System.Drawing.SystemColors.Control
        Me.btnpotvariable.Location = New System.Drawing.Point(10, 215)
        Me.btnpotvariable.Margin = New System.Windows.Forms.Padding(2)
        Me.btnpotvariable.Name = "btnpotvariable"
        Me.btnpotvariable.Size = New System.Drawing.Size(70, 50)
        Me.btnpotvariable.TabIndex = 28
        Me.btnpotvariable.Text = "xʸ"
        Me.btnpotvariable.UseVisualStyleBackColor = False
        '
        'btncos
        '
        Me.btncos.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btncos.FlatAppearance.BorderSize = 0
        Me.btncos.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btncos.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncos.ForeColor = System.Drawing.SystemColors.Control
        Me.btncos.Location = New System.Drawing.Point(86, 271)
        Me.btncos.Margin = New System.Windows.Forms.Padding(2)
        Me.btncos.Name = "btncos"
        Me.btncos.Size = New System.Drawing.Size(70, 50)
        Me.btncos.TabIndex = 35
        Me.btncos.Text = "Cos"
        Me.btncos.UseVisualStyleBackColor = False
        '
        'btntan
        '
        Me.btntan.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btntan.FlatAppearance.BorderSize = 0
        Me.btntan.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btntan.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btntan.ForeColor = System.Drawing.SystemColors.Control
        Me.btntan.Location = New System.Drawing.Point(160, 271)
        Me.btntan.Margin = New System.Windows.Forms.Padding(2)
        Me.btntan.Name = "btntan"
        Me.btntan.Size = New System.Drawing.Size(70, 50)
        Me.btntan.TabIndex = 34
        Me.btntan.Text = "Tan"
        Me.btntan.UseVisualStyleBackColor = False
        '
        'btnlog
        '
        Me.btnlog.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnlog.FlatAppearance.BorderSize = 0
        Me.btnlog.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnlog.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnlog.ForeColor = System.Drawing.SystemColors.Control
        Me.btnlog.Location = New System.Drawing.Point(236, 271)
        Me.btnlog.Margin = New System.Windows.Forms.Padding(2)
        Me.btnlog.Name = "btnlog"
        Me.btnlog.Size = New System.Drawing.Size(70, 50)
        Me.btnlog.TabIndex = 33
        Me.btnlog.Text = "Log"
        Me.btnlog.UseVisualStyleBackColor = False
        '
        'btnsin
        '
        Me.btnsin.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnsin.FlatAppearance.BorderSize = 0
        Me.btnsin.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnsin.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsin.ForeColor = System.Drawing.SystemColors.Control
        Me.btnsin.Location = New System.Drawing.Point(10, 271)
        Me.btnsin.Margin = New System.Windows.Forms.Padding(2)
        Me.btnsin.Name = "btnsin"
        Me.btnsin.Size = New System.Drawing.Size(70, 50)
        Me.btnsin.TabIndex = 32
        Me.btnsin.Text = "Sin"
        Me.btnsin.UseVisualStyleBackColor = False
        '
        'btnmc
        '
        Me.btnmc.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnmc.FlatAppearance.BorderSize = 0
        Me.btnmc.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnmc.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnmc.ForeColor = System.Drawing.SystemColors.Control
        Me.btnmc.Location = New System.Drawing.Point(85, 143)
        Me.btnmc.Margin = New System.Windows.Forms.Padding(2)
        Me.btnmc.Name = "btnmc"
        Me.btnmc.Size = New System.Drawing.Size(70, 50)
        Me.btnmc.TabIndex = 39
        Me.btnmc.Text = "MC"
        Me.btnmc.UseVisualStyleBackColor = False
        '
        'btnmr
        '
        Me.btnmr.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnmr.FlatAppearance.BorderSize = 0
        Me.btnmr.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnmr.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnmr.ForeColor = System.Drawing.SystemColors.Control
        Me.btnmr.Location = New System.Drawing.Point(160, 143)
        Me.btnmr.Margin = New System.Windows.Forms.Padding(2)
        Me.btnmr.Name = "btnmr"
        Me.btnmr.Size = New System.Drawing.Size(70, 50)
        Me.btnmr.TabIndex = 38
        Me.btnmr.Text = "MR"
        Me.btnmr.UseVisualStyleBackColor = False
        '
        'bntms
        '
        Me.bntms.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.bntms.FlatAppearance.BorderSize = 0
        Me.bntms.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bntms.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bntms.ForeColor = System.Drawing.SystemColors.Control
        Me.bntms.Location = New System.Drawing.Point(235, 143)
        Me.bntms.Margin = New System.Windows.Forms.Padding(2)
        Me.bntms.Name = "bntms"
        Me.bntms.Size = New System.Drawing.Size(70, 50)
        Me.bntms.TabIndex = 37
        Me.bntms.Text = "MS"
        Me.bntms.UseVisualStyleBackColor = False
        '
        'txtref
        '
        Me.txtref.BackColor = System.Drawing.SystemColors.WindowFrame
        Me.txtref.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtref.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtref.ForeColor = System.Drawing.Color.White
        Me.txtref.Location = New System.Drawing.Point(10, 38)
        Me.txtref.Margin = New System.Windows.Forms.Padding(2)
        Me.txtref.Multiline = True
        Me.txtref.Name = "txtref"
        Me.txtref.Size = New System.Drawing.Size(296, 40)
        Me.txtref.TabIndex = 40
        Me.txtref.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtpantalla
        '
        Me.txtpantalla.BackColor = System.Drawing.SystemColors.WindowFrame
        Me.txtpantalla.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtpantalla.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpantalla.ForeColor = System.Drawing.Color.White
        Me.txtpantalla.Location = New System.Drawing.Point(10, 83)
        Me.txtpantalla.Margin = New System.Windows.Forms.Padding(2)
        Me.txtpantalla.Multiline = True
        Me.txtpantalla.Name = "txtpantalla"
        Me.txtpantalla.Size = New System.Drawing.Size(296, 40)
        Me.txtpantalla.TabIndex = 41
        Me.txtpantalla.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'lblMEM
        '
        Me.lblMEM.AutoSize = True
        Me.lblMEM.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMEM.ForeColor = System.Drawing.Color.White
        Me.lblMEM.Location = New System.Drawing.Point(254, 4)
        Me.lblMEM.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblMEM.Name = "lblMEM"
        Me.lblMEM.Size = New System.Drawing.Size(37, 31)
        Me.lblMEM.TabIndex = 43
        Me.lblMEM.Text = "M"
        Me.lblMEM.Visible = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.WindowFrame
        Me.ClientSize = New System.Drawing.Size(314, 681)
        Me.Controls.Add(Me.lblMEM)
        Me.Controls.Add(Me.txtpantalla)
        Me.Controls.Add(Me.txtref)
        Me.Controls.Add(Me.btnmc)
        Me.Controls.Add(Me.btnmr)
        Me.Controls.Add(Me.bntms)
        Me.Controls.Add(Me.btncos)
        Me.Controls.Add(Me.btntan)
        Me.Controls.Add(Me.btnlog)
        Me.Controls.Add(Me.btnsin)
        Me.Controls.Add(Me.btndiezx)
        Me.Controls.Add(Me.btnexp)
        Me.Controls.Add(Me.bntpi)
        Me.Controls.Add(Me.btnpotvariable)
        Me.Controls.Add(Me.btnraiz)
        Me.Controls.Add(Me.btncuadrado)
        Me.Controls.Add(Me.btnreciproco)
        Me.Controls.Add(Me.btnporcentaje)
        Me.Controls.Add(Me.btnclear)
        Me.Controls.Add(Me.btnbackspace)
        Me.Controls.Add(Me.btndivision)
        Me.Controls.Add(Me.btnocho)
        Me.Controls.Add(Me.btnnueve)
        Me.Controls.Add(Me.btnmultiplicacion)
        Me.Controls.Add(Me.btnsiete)
        Me.Controls.Add(Me.btncinco)
        Me.Controls.Add(Me.btnseis)
        Me.Controls.Add(Me.btnresta)
        Me.Controls.Add(Me.btncuatro)
        Me.Controls.Add(Me.btndos)
        Me.Controls.Add(Me.btntres)
        Me.Controls.Add(Me.btnsuma)
        Me.Controls.Add(Me.btnuno)
        Me.Controls.Add(Me.btnzero)
        Me.Controls.Add(Me.btnpunto)
        Me.Controls.Add(Me.btnigual)
        Me.Controls.Add(Me.btnmasmenos)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.Text = "Calculadora"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnmasmenos As Button
    Friend WithEvents btnigual As Button
    Friend WithEvents btnpunto As Button
    Friend WithEvents btnzero As Button
    Friend WithEvents btndos As Button
    Friend WithEvents btntres As Button
    Friend WithEvents btnsuma As Button
    Friend WithEvents btnuno As Button
    Friend WithEvents btncinco As Button
    Friend WithEvents btnseis As Button
    Friend WithEvents btnresta As Button
    Friend WithEvents btncuatro As Button
    Friend WithEvents btnocho As Button
    Friend WithEvents btnnueve As Button
    Friend WithEvents btnmultiplicacion As Button
    Friend WithEvents btnsiete As Button
    Friend WithEvents btnclear As Button
    Friend WithEvents btnbackspace As Button
    Friend WithEvents btndivision As Button
    Friend WithEvents btnraiz As Button
    Friend WithEvents btncuadrado As Button
    Friend WithEvents btnreciproco As Button
    Friend WithEvents btnporcentaje As Button
    Friend WithEvents btndiezx As Button
    Friend WithEvents btnexp As Button
    Friend WithEvents bntpi As Button
    Friend WithEvents btnpotvariable As Button
    Friend WithEvents btncos As Button
    Friend WithEvents btntan As Button
    Friend WithEvents btnlog As Button
    Friend WithEvents btnsin As Button
    Friend WithEvents btnmc As Button
    Friend WithEvents btnmr As Button
    Friend WithEvents bntms As Button
    Friend WithEvents txtref As TextBox
    Friend WithEvents txtpantalla As TextBox
    Friend WithEvents lblMEM As Label
End Class
